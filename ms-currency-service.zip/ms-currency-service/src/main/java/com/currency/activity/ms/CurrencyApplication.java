package com.currency.activity.ms;

import java.math.BigDecimal;
import java.net.URI;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.currency.activity.ms.CurrencyBean;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;



@SpringBootApplication
@EnableHystrix
@EnableFeignClients("com.currency.activity.ms")
@EnableDiscoveryClient
@RestController
public class CurrencyApplication {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private static Integer count = 0;

	@Autowired
    private LoadBalancerClient client;
	
	public static void main(String[] args) {
		SpringApplication.run(CurrencyApplication.class, args);
	}
	@RequestMapping(value = "/")
	public String home() {
	   logger.info("Access /");
	  return "OK";
	}

	@PostMapping(path = "/v1/currencies/exchanges/", consumes = "application/json", produces = "application/json")
	@HystrixCommand(fallbackMethod = "convertCurrencyFallback")
	public ResponseEntity<CurrencyBean> convertCurrency(@RequestBody CurrencyBean currency ) throws Exception {
		count++;
		if(count%5 == 0) throw new RuntimeException("Hystrix Fall back");
		
		
		CurrencyBean response = this.getCurrencyConversion("currencyservice",currency);
		logger.info("{}", response);
		
		if(response == null) return ResponseEntity.notFound().build();
		
		CurrencyBean currencyObject = new CurrencyBean(response.getId(), response.getFrom(), response.getTo(), response.getConversionMultiple(), response.getQuantity(),
				currency.getQuantity().multiply(response.getConversionMultiple()), new String("client"));
		return ResponseEntity.ok(currencyObject);
	}
	public ResponseEntity<CurrencyBean> convertCurrencyFallback(CurrencyBean currency) {

		CurrencyBean response = this.getCurrencyConversion("currencyservice", currency);
		logger.info("{}", response);
		
		if(response == null) return ResponseEntity.notFound().build();
		
		CurrencyBean currencyObject = new CurrencyBean(response.getId(), response.getFrom(), response.getTo(), response.getConversionMultiple(), response.getQuantity(),
				currency.getQuantity().multiply(response.getConversionMultiple()), new String("client1"));
		return ResponseEntity.ok(currencyObject);
	}
	public CurrencyBean getCurrencyConversion(String service, CurrencyBean currency) {
		ServiceInstance instance = client.choose(service);
		URI uri = null;
		if(instance != null) {
			uri = URI.create(String.format("http://%s:%s", instance.getHost(), instance.getPort()));//http://localhost:8000/currency-exchange/from/USD/to/INR
		    logger.info("CURRENCYSERVICE PATH :: " , uri.getPath());
	        logger.info("CURRENCYSERVICE HOST :: ", uri.getHost());
	        logger.info("CURRENCYSERVICE PORT :: ", uri.getPort());
	      	if (uri !=null ) {
	      		HttpHeaders headers = new HttpHeaders();
	      		headers.setContentType(MediaType.APPLICATION_JSON);
	      		HttpEntity<CurrencyBean> currencyRequest = new HttpEntity<CurrencyBean>(currency,headers);
	      		String url =uri.toString() + "/v1/getcurrencies/conversions/";
	      		return (new RestTemplate()).postForObject(url,currencyRequest,CurrencyBean.class);
		    }
		}
        return null;
	}

}


